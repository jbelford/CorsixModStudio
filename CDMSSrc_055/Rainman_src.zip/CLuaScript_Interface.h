/*
Rainman Library
Copyright (C) 2006 Corsix <corsix@gmail.com>

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef _LUA_INTERFACE_H_
#define _LUA_INTERFACE_H_
/*
extern "C" {
#include <lua.h>
};
#include "CDoWModule.h"

void LuaBind_Globals(lua_State *L);
void LuaBind_Istream(lua_State *L, IFileStore::IStream* pObj, bool bOwn = true);
void LuaBind_IoutputStream(lua_State *L, IFileStore::IOutputStream* pObj, bool bOwn = true);
void LuaBind_CsgaFile(lua_State *L, CSgaFile* pObj, bool bOwn = true);
void LuaBind_CucsFile(lua_State *L, CUcsFile* pObj, bool bOwn = true);
void LuaBind_CdowModule(lua_State *L, CDoWModule* pObj, bool bOwn = true);
*/
#endif

